<?php
/**
 * Estos son los detalles de inicio de sesi�n de la base de datos: 
 */
define("HOST", "188.121.44.183");     // El alojamiento al que deseas conectarte
define("USER", "segure");    // El nombre de usuario de la base de datos
define("PASSWORD", "kLqt4^05");    // La contrase�a de la base de datos
define("DATABASE", "u292000437_bdi");    // El nombre de la base de datos
 
define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");
 
define("SECURE", FALSE);    // ���SOLO PARA DESARROLLAR!!!!

?>